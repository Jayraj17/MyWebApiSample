﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class CategoryMasterController : Controller
    {
        // GET: CategoryMaster
        PracticeEntities obj = new PracticeEntities();
        public ActionResult Category(int? CatId)
        {
            if (CatId == null)
            {
                var model = new WebApplication1.Models.ProductCategoryCommon()
                {
                    CategoryBind = CategoryList(),
                    CategoryMaster = new CategoryMasterModel()
                };
                return View(model);
            }
            else
            {
                var model = new WebApplication1.Models.ProductCategoryCommon()
                {
                    CategoryBind = CategoryList(),
                    CategoryMaster = CategoryList().ToList().Find(a => a.ID == CatId)
                };
                return View(model);
            }
        }

        public List<CategoryMasterModel> CategoryList()
        {
            var viewmodel = from t in obj.CategoryMasters
                            select new CategoryMasterModel
                                {
                                    ID = t.ID,
                                    CategoryName = t.CategoryName,
                                    Active = t.Active
                                };
            return viewmodel.ToList();
        }

        [HttpPost]
        public ActionResult Action(Models.ProductCategoryCommon objProduct)
        {
            return View();
        }

    }
}