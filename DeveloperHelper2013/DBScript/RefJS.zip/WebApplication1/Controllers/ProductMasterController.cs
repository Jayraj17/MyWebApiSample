﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class ProductMasterController : Controller
    {
        
        // GET: ProductMasterController
        PracticeEntities obj = new PracticeEntities();
        public ActionResult product(int? ProId)
        {
            if (ProId == null)
            {
                var model = new WebApplication1.Models.ProductCategoryCommon()
                {
                    ProductList = ProductList(),
                    CategoryList = obj.CategoryMasters.ToList(),
                    ProductMaster = new ProductMasterModel()
                };
                return View(model);
            }
            else
            {
                var model = new WebApplication1.Models.ProductCategoryCommon()
                {
                    ProductList = ProductList(),
                    CategoryList = obj.CategoryMasters.ToList(),
                    ProductMaster = ProductList().ToList().Find(a => a.ID == ProId)
                };

                return View(model);
            }
        }
        
        public List<ProductMasterModel> ProductList()
        {
            var viewModel = from prod in obj.ProductMasters
                            join cate in obj.CategoryMasters on prod.CategoryID equals cate.ID
                            select new ProductMasterModel
                            {
                                ID = prod.ID,
                                ProductName = prod.ProductName,
                                Description = prod.Description,
                                Image = prod.Image,
                                price = prod.Price,
                                CategoryID = prod.CategoryID,
                                Active = prod.Active,
                                CategoryName = cate.CategoryName
                            };

            return viewModel.ToList();
        }

        [HttpPost]
        public ActionResult SaveData(Models.ProductCategoryCommon objProduct, HttpPostedFileBase postedFile)
        {
            if (ModelState.IsValid)
            {
                string Filename = "";
                if (InsertUpdateData(objProduct, postedFile, ref Filename))
                {
                    if (postedFile != null)
                    {
                        string path = Server.MapPath("~/UplodedFiels/");
                        if (!Directory.Exists(path))
                        {
                            Directory.CreateDirectory(path);
                        }
                        string Ext = Path.GetExtension(path + postedFile.FileName);

                        postedFile.SaveAs(path + Filename + Ext);

                    }
                }
            }
            return RedirectToAction("Product");
        }

        public bool InsertUpdateData(Models.ProductCategoryCommon objProduct, HttpPostedFileBase postedFile, ref string FileName)
        {
            try
            {
                if (postedFile != null)
                {
                    MemoryStream target = new MemoryStream();
                    postedFile.InputStream.CopyTo(target);
                    objProduct.ProductMaster.Image = target.ToArray();
                }
                var objMaster = new WebApplication1.Models.ProductMaster()
                {
                    ID = objProduct.ProductMaster.ID,
                    ProductName = objProduct.ProductMaster.ProductName,
                    Description = objProduct.ProductMaster.Description,
                    Image = objProduct.ProductMaster.Image,
                    Price = objProduct.ProductMaster.price,
                    CategoryID = objProduct.ProductMaster.CategoryID,
                    Active = objProduct.ProductMaster.Active
                };
                ObjectParameter objParam = new ObjectParameter("Result", typeof(int));
                obj.InsertProduct(objMaster.ID, objMaster.ProductName, objMaster.Description, objMaster.Image, objMaster.Price, objMaster.CategoryID, objParam);
                obj.SaveChanges();

                if (Convert.ToInt32(objParam.Value) != 0)
                {
                    if (objMaster.ID == 0)
                    {
                        FileName = objParam.Value.ToString();
                        TempData["Message"] = "Data SaveSuccessfully";
                    }
                    else
                    {
                        FileName = objProduct.ProductMaster.ID.ToString();
                        System.IO.File.Delete(Server.MapPath("~/UplodedFiels/") + FileName);
                        TempData["Message"] = "Data Updated Successfully.";
                    }
                }


                return true;


            }
            catch (Exception)
            {
                return false;
            }
        }

        public ActionResult Delete(int proId)
        {
            Models.ProductMaster objPro = obj.ProductMasters.Find(proId);
            obj.ProductMasters.Remove(objPro);
            obj.SaveChanges();

            string[] filePaths = Directory.GetFiles(Server.MapPath("~/UplodedFiels/"));
            foreach (string filePath in filePaths)
            {
                string filename = Path.GetFileNameWithoutExtension(filePath);
                if (proId.ToString() == filename)
                {
                    System.IO.File.Delete(filePath);
                    TempData["Message"] = "Record Deleted Successfully.";
                }
            }
            return RedirectToAction("Product");
        }

    }
}