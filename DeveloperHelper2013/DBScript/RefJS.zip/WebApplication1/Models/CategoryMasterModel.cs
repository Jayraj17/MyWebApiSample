﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class CategoryMasterModel
    {
        public int ID { get; set; }
        public string CategoryName { get; set; }
        public Nullable<bool> Active { get; set; }
    }
}