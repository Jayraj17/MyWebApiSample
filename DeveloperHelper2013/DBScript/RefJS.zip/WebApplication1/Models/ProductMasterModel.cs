﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class ProductMasterModel
    {
        public int ID { get; set; }
        [Required(ErrorMessage = "Please enter productname.")]
        public string ProductName { get; set; }

        public string Description { get; set; }
        [Required(ErrorMessage = "Please enter price.")]
        public Nullable<decimal> price { get; set; }
        public byte[] Image { get; set; }

        [Required(ErrorMessage = "Please select Category.")]
        public Nullable<int> CategoryID { get; set; }

        public Nullable<bool> Active { get; set; }

        public string CategoryName { get; set; }
        public List<CategoryMasterModel> Categories { get; set; }

    }
}