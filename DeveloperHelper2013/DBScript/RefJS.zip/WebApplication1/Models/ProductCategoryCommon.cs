﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class ProductCategoryCommon
    {
        public List<CategoryMaster> CategoryList { get; set; }

        public List<CategoryMasterModel> CategoryBind { get; set; }
        public List<ProductMasterModel> ProductList { get; set; }

        public ProductMasterModel ProductMaster { get; set; }

        public CategoryMasterModel CategoryMaster { get; set; }
    }
}